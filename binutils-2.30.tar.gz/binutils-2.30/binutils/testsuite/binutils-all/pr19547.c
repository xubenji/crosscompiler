static char foo[]__attribute__ ((used)) = "foo";
