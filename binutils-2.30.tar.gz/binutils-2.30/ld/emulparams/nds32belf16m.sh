. ${srcdir}/emulparams/nds32elf16m.sh
OUTPUT_FORMAT="$BIG_OUTPUT_FORMAT"
